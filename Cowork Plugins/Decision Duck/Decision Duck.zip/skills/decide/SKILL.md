---
name: decide
description: |
  End-to-end decision support orchestrator. Compares options, runs risk
  analysis on the recommended path, runs a bias check on the user's stated
  reasoning, and produces a single decision brief. Use when the user says
  "help me decide", "I need to make a call on this", "walk me through this
  decision", "I'm stuck between these", or shares a real decision they're
  about to commit to. Calls `comparative_analysis`, `analyze_risk`, and
  `identify_cognitive_biases` in sequence.
metadata:
  author: "Troy Taylor"
  version: "1.0"
  pattern: orchestrator
---

# Decide

## What This Skill Does

Runs the full Decision Duck pipeline for a real decision: compare options →
risk-check the recommended path → bias-check the user's reasoning →
assemble a one-page decision brief. Use this when the user is about to
commit, not when they're brainstorming.

## When to Activate

- "Help me decide between …"
- "I need to make a call on …"
- "Walk me through this decision"
- "I'm leaning toward X — what should I check before committing"
- User shares 2+ options AND mentions an upcoming deadline or decision point

## When NOT to Activate

- Just one tool's worth of value is needed → use the focused skill
  (`second-opinion`, `risk-analysis`, `bias-check`, `compare-options`)
- User wants to imagine the project failing → use `pre-mortem`
- User wants an adversarial critique → use `red-team`

## Workflow

1. **Gather the four inputs.** Don't proceed without them — ask one
   consolidated question:
   - **Decision:** what's the call to make, in one sentence
   - **Options:** the alternatives on the table (need ≥2)
   - **Criteria:** what matters (or accept your defaults: cost, speed,
     risk, reversibility, strategic fit)
   - **Current lean and why:** the user's working hypothesis in 2–3 sentences

2. **Step 1 — Compare.**

   ```
   comparative_analysis(
     context: "<decision in one paragraph>",
     options: [...],
     criteria: [...]
   )
   ```

   Capture the recommendation and the killer tradeoff.

3. **Step 2 — Risk the recommended path.**

   ```
   analyze_risk(
     scenario: "Committing to <recommended option> for <decision>",
     context: "<one-paragraph decision background>"
   )
   ```

   Capture the top 3 risks and their leading indicators.

4. **Step 3 — Bias-check the user's reasoning.**

   ```
   identify_cognitive_biases(
     analysis: "<the user's current lean and why, in their own words>"
   )
   ```

   Capture the 1–2 strongest biases.

5. **Step 4 — Assemble the decision brief.** One page, exactly the format
   below. Lead with the recommendation; the user should be able to skim
   the top half and decide.

6. **Close with one decision-quality check.** Pin the question that
   sharpens the call. Examples: "If we run the pilot first, do we still
   pick A?", "If we knew X would change in 6 months, would we pick
   differently?"

## Output Format

```
# Decision brief: <decision in one line>

## Recommendation
**<Recommended option>** — <one-line rationale>

**Killer tradeoff:** <one line>

## Options compared

| Criterion | Option A | Option B | Option C |
|-----------|---------|---------|---------|
| …         | …       | …       | …       |

## Top risks on the recommended path
| Risk | P/I | Mitigation | Leading indicator |
|------|-----|-----------|-------------------|
| …    | …   | …         | …                 |

## Bias check on your reasoning
- **<Bias>** — <how it shows up here> — <correction>

## Decision-quality check
> <one sharp question>

## What would change the recommendation
- …
```

## Handling Edge Cases

- **Only one option.** Don't fake a comparison — push back and offer to
  hand off to `second-opinion` instead.
- **No "current lean and why".** Skip the bias check rather than fabricate
  one. Note in the brief: "Bias check skipped — no stated reasoning to review."
- **Any tool fails.** Continue with the rest of the pipeline and note
  the missing section in the brief. Don't block the whole flow on one
  call.
- **Long-running.** This skill does 3 tool calls. If the user is in a
  hurry, offer the "quick" variant: only `comparative_analysis`, then
  ask whether to run the other two.

## Handling Authentication

Same as the other Decision Duck skills — surface the sign-in prompt on the
first auth failure and don't retry until the user confirms.
