---
name: decision-frameworks
description: |
  Lists and explains available decision-making frameworks (RICE, OODA loop,
  Eisenhower matrix, Bezos one-way/two-way doors, Cynefin, WRAP, and others
  on the server). Use when the user asks "what framework should I use",
  "explain RICE", "what's a one-way door decision", "give me a decision
  framework for this", "what frameworks do you have". Calls the
  `list_frameworks` and `get_framework` MCP tools.
metadata:
  author: "Troy Taylor"
  version: "1.0"
  pattern: knowledge
---

# Decision Frameworks

## What This Skill Does

Surfaces the decision-framework library hosted on the Decision Duck MCP
server and helps the user pick or apply one. Frameworks are static knowledge
resources — fast, deterministic, no LLM call.

## When to Activate

- User asks "what framework should I use for this decision"
- User asks to explain a specific framework by name (RICE, OODA, Eisenhower,
  Cynefin, WRAP, one-way / two-way doors, etc.)
- User wants to see what frameworks are available
- User describes a decision and asks "is there a framework that fits this"

## Workflow

1. **Detect the ask.**
   - "List frameworks" / "what do you have" → call `list_frameworks`.
   - "Explain X" / "tell me about X" / "use X" → call
     `get_framework(framework_id: "<id>")`. If you don't know the exact id,
     call `list_frameworks` first to map the name to an id.

2. **For "which framework fits my decision":** ask one clarifying question
   to characterize the decision shape:
   - Is it reversible or irreversible? (suggests one-way / two-way doors)
   - Is it a prioritization? (suggests RICE, Eisenhower)
   - Is it under uncertainty or time pressure? (suggests OODA, WRAP)
   - Is it a complex/novel domain? (suggests Cynefin)
   Then call `get_framework` for the best match and offer 1–2 alternatives.

3. **Tool calls.**

   ```
   list_frameworks()
   get_framework(framework_id: "rice")
   ```

4. **Present the framework with structure.** Don't paste a wall of text —
   pull out: **what it is**, **when to use it**, **steps**, **example**.

5. **Offer the next move.** If the user picked a framework, offer to run
   their decision through it now (handing off to `decide`, `compare-options`,
   or `risk-analysis` as appropriate).

## Output Format

For a single framework:

```
### <Framework name>

**What it is:** <one paragraph>

**Use it when:** <one line>

**Steps:**
1. …
2. …

**Example:** <short worked example>

Want me to walk through your decision using this?
```

For a list:

```
**Available decision frameworks:**

- **RICE** — prioritize features/initiatives by Reach × Impact × Confidence ÷ Effort
- **OODA loop** — fast decisions under uncertainty (Observe, Orient, Decide, Act)
- **Eisenhower matrix** — urgent vs important quadrants
- **One-way / two-way doors** — reversible vs irreversible decisions
- …

Want me to dive into one of these?
```

## Handling Edge Cases

- **Framework id unknown.** If `get_framework` returns "not found", fall
  back to `list_frameworks` and tell the user what's available.
- **User asks for a framework that isn't on the server.** Don't fabricate
  a built-in one. Describe it from general knowledge if you can, but make
  clear it's not in the Decision Duck library.

## Handling Authentication

Same pattern as the other Decision Duck skills.
