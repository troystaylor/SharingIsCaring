---
name: compare-options
description: |
  Compares two or more options against criteria and recommends one with
  rationale. Use when the user says "compare these options", "which should
  we pick", "give me a tradeoff matrix", "X vs Y", "help me choose between",
  or lists multiple alternatives and wants a structured comparison. Calls
  the Decision Duck `comparative_analysis` MCP tool.
metadata:
  author: "Troy Taylor"
  version: "1.0"
  pattern: analysis
---

# Compare Options

## What This Skill Does

Takes two or more options, optional decision criteria, and the context they
sit in, then returns a side-by-side comparison, an explicit tradeoff
discussion, and a recommendation with rationale. Wraps the
`comparative_analysis` tool.

## When to Activate

- User says "compare A vs B" or "which should we pick"
- User asks for a "tradeoff matrix", "decision matrix", or "pros and cons"
- User lists 2+ alternatives in one message and asks for help choosing
- User asks "what's the right path forward" with multiple paths on the table

## When NOT to Activate

- Only one option is on the table → use `second-opinion` or `risk-analysis`
- User wants a full decision package with bias check too → use `decide`

## Workflow

1. **Confirm context, options, and criteria.** Repeat back:
   - **Context:** one paragraph
   - **Options:** numbered list
   - **Criteria:** if the user didn't name any, propose 3–5 sensible defaults
     (cost, speed, risk, reversibility, strategic fit) and ask them to
     accept/edit.

2. **Call the tool.**

   ```
   comparative_analysis(
     context: "<one-paragraph background>",
     options: ["Option A", "Option B", …],
     criteria: ["cost", "speed", "risk", …]
   )
   ```

3. **Present a comparison table first, then the recommendation.** Rows are
   criteria, columns are options. Use a single best/worst marker per row to
   make it scannable.

4. **Call out the killer tradeoff explicitly.** One sentence: "Choosing
   Option A means accepting <X> in exchange for <Y>."

5. **Recommend one option and the reasoning.** Don't hedge with "it depends".
   The tool already returns a recommendation — surface it clearly and give
   the user permission to override.

## Output Format

```
**Comparing options:** <one-line context>

| Criterion | Option A | Option B | Option C |
|-----------|---------|---------|---------|
| Cost      | …       | …       | …       |
| Speed     | …       | …       | …       |
| Risk      | …       | …       | …       |

**The killer tradeoff:** <one line>

**Recommendation: Option B**
- Why: …
- What you give up: …
- What would change my recommendation: …
```

## Handling Edge Cases

- **Only one option.** Push back: "Comparison needs at least two. Want me
  to brainstorm an alternative or two first?"
- **Too many options (>5).** Suggest a two-stage cut: quickly disqualify any
  that fail must-have criteria, then deep compare the survivors.
- **Criteria conflict.** If the user's criteria push in opposite directions
  (e.g. lowest cost AND lowest risk), name it and ask which one wins ties.
- **Fallback model.** If metadata shows model = `fallback`, note it.

## MCP Apps note (M365 Copilot only)

The Decision Duck MCP server advertises a UI resource for comparative
analysis (`ui://decision-duck/comparative-analysis.html`). Cowork does not
render inline UI resources, so you'll always present the comparison as a
markdown table here. The same plugin in Microsoft 365 Copilot will render
the inline app view — no change needed in this skill.

## Handling Authentication

Same as the other Decision Duck skills.
