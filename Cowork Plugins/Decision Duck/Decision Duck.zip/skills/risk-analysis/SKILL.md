---
name: risk-analysis
description: |
  Produces a structured risk analysis with probability/impact estimates,
  mitigations, and leading indicators. Use when the user asks "what could go
  wrong", "what are the risks", "give me a risk register", "what should I
  watch out for", "are there risks in this plan", or shares a scenario and
  wants the failure modes mapped out. Calls the Decision Duck `analyze_risk`
  MCP tool.
metadata:
  author: "Troy Taylor"
  version: "1.0"
  pattern: analysis
---

# Risk Analysis

## What This Skill Does

Turns a scenario or plan into a usable risk register: key risks with
probability and impact, suggested mitigations, and leading indicators that
will signal each risk is materializing. Wraps the `analyze_risk` tool.

## When to Activate

- User asks "what could go wrong" / "what are the risks" / "what's the
  worst case"
- User wants a risk register, risk assessment, or risk matrix
- User shares a plan, launch, migration, deal, or hire and asks what to
  worry about
- User wants "leading indicators" or "tripwires" for a plan

## When NOT to Activate

- User wants to imagine the project failing and work backward → use `pre-mortem`
- User wants an adversarial critique of their reasoning → use `red-team`
- User wants to compare options → use `compare-options`

## Workflow

1. **Restate the scenario.** Confirm what you're analyzing in one line.

2. **Probe for context and prioritized categories.** Ask (optional, don't
   block) whether they want to prioritize specific categories:
   - Financial / cost
   - Schedule / delivery
   - Technical / operational
   - People / team
   - Customer / reputational
   - Legal / compliance
   - Security / privacy

3. **Call the tool.**

   ```
   analyze_risk(
     scenario: "<one-paragraph scenario>",
     context: "<optional background>",
     risk_categories: ["<optional prioritization>", …]
   )
   ```

4. **Present as a table.** Most useful format for risks. Five columns:
   Risk, Probability, Impact, Mitigation, Leading indicator.

5. **Call out top 3.** After the table, name the top 3 to act on this week.

## Output Format

```
**Risk analysis: <one-line scenario>**

| Risk | Probability | Impact | Mitigation | Leading indicator |
|------|-------------|--------|-----------|-------------------|
| …    | High        | High   | …         | …                 |

**Top 3 to act on this week:**
1. …
2. …
3. …
```

## Handling Edge Cases

- **Scenario too vague.** If the user just says "what are the risks of the
  reorg", ask one clarifying question: what's the scope and timeline?
- **User pushes back on a risk.** Don't argue. Offer to re-run with their
  framing as additional context.
- **Long list.** If the tool returns more than ~8 risks, group by category
  and ask whether the user wants to focus on one.
- **Fallback model.** If the result metadata shows model = `fallback`,
  surface a one-line note so the user knows the heuristic ran instead of
  the LLM.

## Handling Authentication

Same pattern as the rest of the plugin: if the tool fails with an auth error,
ask the user to complete the Decision Duck sign-in prompt and don't retry
until they confirm.
